import { Component } from '@angular/core';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { GithubService } from 'src/github.service';

@Component({
  selector: 'app-report-form',
  templateUrl: './report-form.component.html',
  styleUrls: ['./report-form.component.scss']
})
export class ReportFormComponent {
  owner = '';
  repo = '';
  showTokenModal = false;
  since = '';
  userToken: string = '';
  showHelpMessage: boolean = false;  // Flag to show/hide help message
  until = '';
  startDate = '';
  endDate = '';
  commits: any[] = [];
  username = ''; // or bind from UI
  repos: any[] = [];
  totalCommits: number = 0;
  tokenInvalid: boolean = false; 
  showUpdateTokenModal: boolean = false;

  constructor(private githubService: GithubService) {}

  // Generate report for a single repo and date range
  generateReport() {
    
    if (!this.owner || !this.repo || !this.since || !this.until) {
      alert('Please fill all fields.');
      return;
    }

    this.githubService.getCommits(this.owner, this.repo, this.since, this.until)
      .subscribe(data => {
        this.commits = data.map(commit => ({
          repoName: this.repo,
          message: commit.commit.message,
          author: commit.commit.author.name,
          date: new Date(commit.commit.author.date).toLocaleDateString()
        }));
        this.createPDF(this.commits);
      }, error => {
        if (error.status === 401 || error.error?.message === 'Bad credentials') {
          alert('GitHub token is expired or invalid. Please update your token.');
        } else {
          alert('An error occurred while fetching repositories.');
        }
      });
  }
   // Function to open the modal
   openModal() {
    this.showUpdateTokenModal = true;
  }

  // Function to close the modal (optional, you can add a close button in your modal)
  closeModal() {
    this.showUpdateTokenModal = false;
  }

  // Generate report for all repos under username, with date filter
  fetchAndGenerateReport() {
    if (!this.username || !this.startDate || !this.endDate) {
      alert('Please enter username and date range');
      return;
    }
  
    this.githubService.getRepos(this.username).subscribe(repos => {
      this.repos = repos;
  
      const commitRequests = repos.map(repo =>
        this.githubService.getCommits(this.username, repo.name).toPromise()
          .catch(() => undefined) // Gracefully handle individual repo failure
      );
  
      Promise.all(commitRequests).then((results: (any[] | undefined)[]) => {
        const filteredCommits: any[] = [];
  
        results.forEach((commits, index) => {
          const repo = this.repos[index];
          if (Array.isArray(commits)) {
            const filtered = commits
              .filter(commit => {
                const date = new Date(commit.commit.author.date);
                return date >= new Date(this.startDate) && date <= new Date(this.endDate);
              })
              .map(commit => ({
                repoName: repo.name,
                message: commit.commit.message,
                author: commit.commit.author.name,
                date: new Date(commit.commit.author.date).toLocaleDateString()
              }));
  
            filteredCommits.push(...filtered);
          }
        });
  
        this.totalCommits = filteredCommits.length;
        this.createPDF(filteredCommits);
      }).catch(err => {
        if (err.status === 401 || err.error?.message === 'Bad credentials') {
          alert('GitHub token is expired or invalid. Please update your token.');
        } else {
          alert('An error occurred while fetching repositories.');
        }
        console.error(err);
        alert('Error fetching commits.');
      });
    });
  }

  showHelp() {
    this.showHelpMessage = true;
  }

  // Function to hide the help message
  hideHelp() {
    this.showHelpMessage = false;
  }


 
  updateToken() {
    if (this.userToken.trim() === '') {
      alert('Please enter a valid token.');
      return;
    }
  
    this.githubService.setToken(this.userToken);
    alert('Token updated successfully!');
    this.tokenInvalid = false; // hide input section after successful update
  }
  
  
  

  createPDF(commits: any[]) {
    const doc = new jsPDF();
    doc.text(`GitHub Commit Report for ${this.username}`, 10, 10);
    doc.text(`Date range: ${this.startDate || '...'} to ${this.endDate || '...'}`, 10, 18);
    doc.text(`Total Projects: ${this.repos.length}`, 10, 26);
    doc.text(`Total Commits: ${commits.length}`, 10, 34);

    autoTable(doc, {
      startY: 40,
      head: [['Repo', 'Message', 'Author', 'Date']],
      body: commits.map(c => [c.repoName, c.message, c.author, c.date])
    });

    doc.save(`${this.username}-commit-report.pdf`);
  }
}
