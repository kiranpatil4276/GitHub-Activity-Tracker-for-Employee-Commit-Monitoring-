import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatetokenModalComponent } from './updatetoken-modal.component';

describe('UpdatetokenModalComponent', () => {
  let component: UpdatetokenModalComponent;
  let fixture: ComponentFixture<UpdatetokenModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UpdatetokenModalComponent]
    });
    fixture = TestBed.createComponent(UpdatetokenModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
