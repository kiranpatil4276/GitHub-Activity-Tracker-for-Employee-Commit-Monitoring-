import { Component, EventEmitter, Input, Output } from '@angular/core';
import { GithubService } from 'src/github.service';

@Component({
  selector: 'app-updatetoken-modal',
  templateUrl: './updatetoken-modal.component.html',
  styleUrls: ['./updatetoken-modal.component.scss']
})
export class UpdatetokenModalComponent {
  @Input() title: string = '';
  userToken: string = '';
  tokenInvalid: boolean = false; 
  @Output() close = new EventEmitter<void>();

  constructor(private githubService:GithubService){

  }

  showTokenModal = false;

  openModal() {
    this.showTokenModal = true;
  }
  
  closeModal() {
    this.showTokenModal = false;
  }
   
  updateToken() {
    if (this.userToken.trim() === '') {
      alert('Please enter a valid token.');
      return;
    }
  
    this.githubService.setToken(this.userToken);
    alert('Token updated successfully!');
    this.tokenInvalid = false; // hide input section after successful update
  }
  
}
