import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class GithubService {
  private data = '';
  constructor(private http: HttpClient) {
    const savedToken = localStorage.getItem('github_token');
    if (savedToken) {
      this.data = savedToken;
    }
  }

  setToken(token: string) {
    this.data = token;
    localStorage.setItem('github_token', token);
  }

  getRepos(username: string): Observable<any[]> {
    return this.http.get<any[]>(`https://api.github.com/users/${username}/repos`);
  }
  
  getCommits(owner: string, repo: string, since?: string, until?: string): Observable<any[]> {
    let url = `https://api.github.com/repos/${owner}/${repo}/commits`;
    const params: any = {};
  
    if (since) params.since = since;
    if (until) params.until = until;
  
    return this.http.get<any[]>(url, { params });
  }

  
  
}
